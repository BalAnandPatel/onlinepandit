<div id="wa-widget" style="bottom: 65px; right: 16px; opacity: 1; transition: opacity 0.5s ease 0s; box-sizing: border-box; direction: ltr; text-align: right; position: fixed !important; z-index: 16000160 !important;">
  <div>
    <div style="display:flex;margin:7px;position:relative;-webkit-box-pack:end;justify-content:flex-end;">
      <a size="50" href="https://wa.me/6390406468?text=Hello" target="_blank" color="#4dc247" class="wa-link" style="
      flex-shrink: 0;
      width: 50px;
      height: 50px;
      order: 2;
      padding: 5px;
      box-sizing: border-box;
      border-radius: 50%;
      cursor: pointer;
      overflow: hidden;
      box-shadow: rgb(0 0 0 / 40%) 2px 2px 6px;
      transition: all 0.5s ease 0s;
      position: relative;
      z-index: 200;
      display: block;
      border: 0;
      background-color: #4dc247 !important;
    ">
        <svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="width: 100%; height: 100%; fill: rgb(255, 255, 255); stroke: none;">
          <path d="M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.09-.832-2.335-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 1.318-1.06 2.264v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.506 3.41 4.554 4.34.616.287 2.035.888 2.722.888.817 0 2.15-.515 2.478-1.318.13-.33.244-.73.244-1.088 0-.058 0-.144-.03-.215-.1-.172-2.434-1.39-2.678-1.39zm-2.908 7.593c-1.747 0-3.48-.53-4.942-1.49L7.793 24.41l1.132-3.337a8.955 8.955 0 0 1-1.72-5.272c0-4.955 4.04-8.995 8.997-8.995S25.2 10.845 25.2 15.8c0 4.958-4.04 8.998-8.998 8.998zm0-19.798c-5.96 0-10.8 4.842-10.8 10.8 0 1.964.53 3.898 1.546 5.574L5 27.176l5.974-1.92a10.807 10.807 0 0 0 16.03-9.455c0-5.958-4.842-10.8-10.802-10.8z">
          </path>
        </svg>
      </a>
    </div>
  </div>
</div>


<footer class="sigma_footer footer-2 sigma_footer-dark">

  <!-- Middle Footer -->
  <div class="sigma_footer-middle">
    <div class="container">
      <div class="row">
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 footer-widget">
          <h5 class="widget-title">About Us</h5>
          <p class="mb-4">You need to be sure there isn’t anything embarrassing hidden in the middle of text. </p>
          <div class="d-flex align-items-center justify-content-md-start justify-content-center">
            <i class="far fa-phone custom-primary me-3"></i>
            <span>(+91) 639-040-6468</span>
          </div>
          <div class="d-flex align-items-center justify-content-md-start justify-content-center mt-2">
            <i class="far fa-envelope custom-primary me-3"></i>
            <span>gauravpsln18@gmail.com</span>
          </div>
          <div class="d-flex align-items-center justify-content-md-start justify-content-center mt-2">
            <i class="far fa-map-marker custom-primary me-3"></i>
            <span>Uttar barthiya Durga Mandir Sarai palaya Bengaluru Karnataka 560077</span>
          </div>
        </div>
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 footer-widget">
          <h5 class="widget-title">Information</h5>
          <ul>
            <li> <a href="about-us.html">About Us</a> </li>
            <li> <a href="contact-us.html">Contact Us</a> </li>
          </ul>
        </div>


      </div>
    </div>
  </div>

  <!-- Footer Bottom -->


</footer>
<!-- partial --> <!-- partial:partia/__scripts.html -->
<script src="assets/js/plugins/jquery-3.4.1.min.js"></script>
<script src="assets/js/plugins/popper.min.js"></script>
<script src="assets/js/plugins/bootstrap.min.js"></script>
<script src="assets/js/plugins/imagesloaded.min.js"></script>
<script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>
<script src="assets/js/plugins/jquery.countdown.min.js"></script>
<script src="assets/js/plugins/jquery.waypoints.min.js"></script>
<script src="assets/js/plugins/jquery.counterup.min.js"></script>
<script src="assets/js/plugins/jquery.zoom.min.js"></script>
<script src="assets/js/plugins/jquery.inview.min.js"></script>
<script src="assets/js/plugins/jquery.event.move.js"></script>
<script src="assets/js/plugins/wow.min.js"></script>
<script src="assets/js/plugins/isotope.pkgd.min.js"></script>
<script src="assets/js/plugins/slick.min.js"></script>
<script src="assets/js/plugins/ion.rangeSlider.min.js"></script>

<script src="assets/js/main.js"></script>
<!-- partial -->

</body>


<!-- Mirrored from metropolitanhost.com/themes/themeforest/html/maharatri/home-v3.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2024 12:57:22 GMT -->

<!-- Mirrored from onlinepandit.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Jun 2024 04:17:44 GMT -->

</html>