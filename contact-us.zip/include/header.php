<!DOCTYPE html>
<html lang="en" dir="ltr">


<!-- Mirrored from metropolitanhost.com/themes/themeforest/html/maharatri/home-v3.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Apr 2024 12:55:36 GMT -->

<!-- Mirrored from onlinepandit.in/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 03 Jun 2024 04:16:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pt. Gaurav Shastri</title>

  <!-- Favicon -->
  <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico">

  <!-- partial:partial/__stylesheets.html -->
  <link rel="stylesheet" href="assets/css/plugins/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
  <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">
  <link rel="stylesheet" href="assets/css/plugins/slick.css">
  <link rel="stylesheet" href="assets/css/plugins/slick-theme.css">
  <link rel="stylesheet" href="assets/css/plugins/ion.rangeSlider.min.css">

  <!-- Icon Fonts -->
  <link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
  <link rel="stylesheet" href="assets/css/plugins/font-awesome.min.css">
  <!-- Template Style sheet -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/responsive.css">
  <!-- partial -->
  
</head>

<body>

  <!-- Preloader Start -->
  <!-- <div class="sigma_preloader">
    <img src="assets/img/om.svg" alt="preloader">
  </div> -->
  <!-- Preloader End -->


  <!-- partial:partia/__mobile-nav.html -->
  <aside class="sigma_aside sigma_aside-left">
    <a class="navbar-brand" href="index-2.html"> <img src="assets/img/logo.webp" width="60px" alt="logo"> </a>
    <!-- Menu -->
  </aside>
  <div class="sigma_aside-overlay aside-trigger-left"></div>
  <!-- partial -->

  <!-- partial:partia/__header.html -->
<header class="sigma_header header-4 can-sticky header-absolute">

<!-- Top Header Start -->
<div class="sigma_header-top">
  <div class="container-fluid">
    <div class="sigma_header-top-inner">
      <ul class="sigma_header-top-links">
        <li class="menu-item"> <a href="tel:+916390406468"> <i class="fal fa-phone"></i>(+91) 639-040-6468</a> </li>
        <li class="menu-item"> <a href="mailto:gauravpsln18@gmail.com"> <i class="fal fa-envelope"></i>gauravpsln18@gmail.com
        </a> </li>
      </ul>
    
    </div>
  </div>
</div>
<!-- Top Header End -->

<!-- Middle Header Start -->
<div class="sigma_header-middle">
  <div class="container-fluid">
    <nav class="navbar">

      <!-- Logo Start -->
      <div class="sigma_logo-wrapper">
        <a class="navbar-brand" href="index-2.html">
          <img src="assets/img/logo.webp" width="60px" alt="logo">
        </a>
      </div>
      <!-- Logo End -->

      <!-- Menu -->
      <ul class="navbar-nav">
          <li class="menu-item">
            <a href="index.php">Home</a>
          </li>
          <li class="menu-item"> <a href="about-us.php">About</a> </li>
          <li class="menu-item">
            <a href="contact-us.php">Contact</a>
          </li>
        </ul>
    </nav>
  </div>
</div>
<!-- Middle Header End -->

</header>